const passport = require("passport");
const LocalStrategy = require("passport-local").Strategy;
const bcrypt = require("bcryptjs");
const User = require("../models/User");

passport.use(new LocalStrategy(
  { usernameField: "email", passwordField: "password" },
  async (email, password, done) => {
    try {
      const user = await User.findOne({ email: email.toLowerCase() });

      if (!user) return done(null, false, { message: "Credenciales incorrectas" });

      const passwordOk = await bcrypt.compare(password, user.password);
      if (!passwordOk) return done(null, false, { message: "Credenciales incorrectas" });

      if (!user.verificado) {
        return done(null, false, { message: "Debes verificar tu cuenta primero" });
      }

      return done(null, user);
    } catch (error) {
      return done(error);
    }
  }
));

passport.serializeUser((user, done) => {
  done(null, user.id);
});

passport.deserializeUser(async (id, done) => {
  try {
    const user = await User.findById(id);
    done(null, user);
  } catch (error) {
    done(error);
  }
});

module.exports = passport;