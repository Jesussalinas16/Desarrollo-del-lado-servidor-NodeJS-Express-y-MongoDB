const jwt = require("jsonwebtoken");

function requireLogin(req, res, next) {
  if (req.isAuthenticated && req.isAuthenticated()) return next();
  return res.redirect("/login");
}

function requireJWT(req, res, next) {
  const auth = req.headers.authorization || "";
  const parts = auth.split(" ");

  if (parts.length !== 2 || parts[0] !== "Bearer") {
    return res.status(401).json({ error: "Debes autenticarte con un token JWT" });
  }

  try {
    const payload = jwt.verify(parts[1], process.env.JWT_SECRET || "jwt-secret");
    req.user = payload;
    next();
  } catch (error) {
    return res.status(401).json({ error: "Token inválido o expirado" });
  }
}

module.exports = { requireLogin, requireJWT };