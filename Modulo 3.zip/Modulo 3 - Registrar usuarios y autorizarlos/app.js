require("dotenv").config();

const express = require("express");
const session = require("express-session");
const passport = require("passport");
const mongoose = require("mongoose");

require("./config/passport");

const authRoutes = require("./routes/auth");
const bikeRoutes = require("./routes/bikes");
const pageRoutes = require("./routes/pages");

const app = express();

app.use(express.urlencoded({ extended: true }));
app.use(express.json());
app.use(express.static("public"));

app.use(session({
  secret: process.env.SESSION_SECRET || "session-secret",
  resave: false,
  saveUninitialized: false
}));

app.use(passport.initialize());
app.use(passport.session());

app.use("/", pageRoutes);
app.use("/auth", authRoutes);
app.use("/api/bikes", bikeRoutes);

app.use((req, res) => {
  res.status(404).json({ error: "Recurso no encontrado" });
});

const PORT = process.env.PORT || 3000;

mongoose.connect(process.env.MONGODB_URI || "mongodb://127.0.0.1:27017/modulo3")
  .then(() => {
    app.listen(PORT, () => {
      console.log(`Servidor iniciado en http://localhost:${PORT}`);
    });
  })
  .catch((err) => {
    console.error("No se pudo conectar a MongoDB:", err.message);
    process.exit(1);
  });