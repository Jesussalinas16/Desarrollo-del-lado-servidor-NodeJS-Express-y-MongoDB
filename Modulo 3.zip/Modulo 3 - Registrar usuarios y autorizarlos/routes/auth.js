const express = require("express");
const crypto = require("crypto");
const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");
const passport = require("passport");

const User = require("../models/User");
const Token = require("../models/Token");
const { sendEmail } = require("../services/mailer");

const router = express.Router();

router.post("/register", async (req, res) => {
  try {
    const email = String(req.body.email || "").trim().toLowerCase();
    const password = String(req.body.password || "");

    if (!email || !password || password.length < 6) {
      return res.status(400).json({ error: "Email y password son obligatorios. Password mínimo 6 caracteres." });
    }

    if (await User.findOne({ email })) {
      return res.status(409).json({ error: "El usuario ya existe" });
    }

    const hashedPassword = await bcrypt.hash(password, 10);
    const user = await User.create({ email, password: hashedPassword });

    const tokenValue = crypto.randomBytes(32).toString("hex");
    await Token.create({ usuario: user._id, token: tokenValue });

    const link = `${process.env.BASE_URL || "http://localhost:3000"}/auth/verify/${tokenValue}`;

    await sendEmail({
      to: email,
      subject: "Bienvenido - verifica tu cuenta",
      html: `<h2>Bienvenido</h2><p>Tu cuenta fue creada.</p><p>Verifica tu cuenta aquí:</p><a href="${link}">${link}</a>`
    });

    res.status(201).json({
      message: "Usuario registrado. Revisa el correo para verificar la cuenta.",
      verificationLinkDemo: link
    });
  } catch (error) {
    res.status(500).json({ error: "Error al registrar usuario", detalle: error.message });
  }
});

router.get("/verify/:token", async (req, res) => {
  try {
    const tokenDoc = await Token.findOne({ token: req.params.token });
    if (!tokenDoc) return res.status(400).send("Token de verificación inválido.");

    const user = await User.findById(tokenDoc.usuario);
    if (!user) return res.status(404).send("Usuario no encontrado.");

    user.verificado = true;
    await user.save();
    await Token.deleteOne({ _id: tokenDoc._id });

    res.send("<h2>Cuenta verificada correctamente.</h2><a href='/login'>Ir al login</a>");
  } catch (error) {
    res.status(500).send("Error al verificar la cuenta.");
  }
});

router.post("/login", passport.authenticate("local", {
  failureRedirect: "/login?error=1"
}), (req, res) => {
  res.redirect("/privado");
});

router.post("/login-jwt", async (req, res) => {
  try {
    const email = String(req.body.email || "").trim().toLowerCase();
    const password = String(req.body.password || "");

    const user = await User.findOne({ email });
    if (!user) return res.status(401).json({ error: "Credenciales incorrectas" });

    const ok = await bcrypt.compare(password, user.password);
    if (!ok) return res.status(401).json({ error: "Credenciales incorrectas" });

    if (!user.verificado) {
      return res.status(403).json({ error: "Cuenta no verificada" });
    }

    const token = jwt.sign(
      { userId: user._id.toString(), email: user.email },
      process.env.JWT_SECRET || "jwt-secret",
      { expiresIn: "1h" }
    );

    res.json({ message: "Autenticación correcta", token });
  } catch (error) {
    res.status(500).json({ error: "Error de autenticación" });
  }
});

router.get("/logout", (req, res) => {
  req.logout(() => res.redirect("/"));
});

router.post("/forgot-password", async (req, res) => {
  try {
    const email = String(req.body.email || "").trim().toLowerCase();
    const user = await User.findOne({ email });

    if (!user) return res.json({ message: "Si el correo existe, se enviará un enlace de recuperación." });

    const resetToken = crypto.randomBytes(32).toString("hex");
    user.passwordResetToken = resetToken;
    user.passwordResetTokenExpires = new Date(Date.now() + 60 * 60 * 1000);
    await user.save();

    const link = `${process.env.BASE_URL || "http://localhost:3000"}/reset-password/${resetToken}`;

    await sendEmail({
      to: email,
      subject: "Recuperación de contraseña",
      html: `<h2>Recuperación de contraseña</h2><p>Usa este enlace:</p><a href="${link}">${link}</a>`
    });

    res.json({ message: "Solicitud procesada", resetLinkDemo: link });
  } catch (error) {
    res.status(500).json({ error: "Error al recuperar contraseña" });
  }
});

router.post("/reset-password/:token", async (req, res) => {
  try {
    const user = await User.findOne({
      passwordResetToken: req.params.token,
      passwordResetTokenExpires: { $gt: new Date() }
    });

    if (!user) return res.status(400).json({ error: "Token de recuperación inválido o expirado" });

    user.password = await bcrypt.hash(String(req.body.password || ""), 10);
    user.passwordResetToken = null;
    user.passwordResetTokenExpires = null;
    await user.save();

    res.json({ message: "Contraseña actualizada correctamente" });
  } catch (error) {
    res.status(500).json({ error: "No se pudo cambiar la contraseña" });
  }
});

module.exports = router;