const express = require("express");
const Bike = require("../models/Bike");
const { requireJWT } = require("../middleware/auth");

const router = express.Router();

router.get("/", requireJWT, async (req, res) => {
  try {
    const bikes = await Bike.find();
    res.json({ usuario: req.user.email, bicicletas: bikes });
  } catch (error) {
    res.status(500).json({ error: "Error al consultar bicicletas" });
  }
});

router.post("/", requireJWT, async (req, res) => {
  try {
    const bike = await Bike.create(req.body);
    res.status(201).json(bike);
  } catch (error) {
    res.status(400).json({ error: "Datos de bicicleta inválidos" });
  }
});

module.exports = router;