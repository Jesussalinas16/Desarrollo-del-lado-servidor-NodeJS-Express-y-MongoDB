# Pruebas para Postman

## A. Registro

POST http://localhost:3000/auth/register

Body -> raw -> JSON:

{
  "email": "alumno@example.com",
  "password": "123456"
}

## B. Login JWT correcto

POST http://localhost:3000/auth/login-jwt

{
  "email": "alumno@example.com",
  "password": "123456"
}

Resultado esperado:
{
  "message": "Autenticación correcta",
  "token": "..."
}

## C. Login JWT incorrecto

POST http://localhost:3000/auth/login-jwt

{
  "email": "alumno@example.com",
  "password": "incorrecta"
}

Resultado esperado: HTTP 401.

## D. Bicicletas SIN token

GET http://localhost:3000/api/bikes

Resultado esperado: HTTP 401.

## E. Bicicletas CON token

GET http://localhost:3000/api/bikes

Authorization:
Bearer <TOKEN_OBTENIDO_EN_EL_LOGIN>

Resultado esperado: HTTP 200 y las bicicletas.

## F. Protección del navegador

Sin sesión:
GET http://localhost:3000/privado

Resultado esperado: redirección a `/login`.

Con sesión:
entrar primero por `/login` con Passport y después abrir `/privado`.
