const nodemailer = require("nodemailer");

async function sendEmail({ to, subject, html }) {
  if (!process.env.SMTP_USER || !process.env.SMTP_PASS) {
    console.log("\n[DEMO EMAIL]");
    console.log("Para:", to);
    console.log("Asunto:", subject);
    console.log("Contenido:", html);
    console.log("[Configura SMTP_USER y SMTP_PASS en .env para enviar correos reales]\n");
    return;
  }

  const transporter = nodemailer.createTransport({
    host: process.env.SMTP_HOST || "smtp.gmail.com",
    port: Number(process.env.SMTP_PORT || 587),
    secure: false,
    auth: {
      user: process.env.SMTP_USER,
      pass: process.env.SMTP_PASS
    }
  });

  await transporter.sendMail({
    from: process.env.MAIL_FROM || process.env.SMTP_USER,
    to,
    subject,
    html
  });
}

module.exports = { sendEmail };