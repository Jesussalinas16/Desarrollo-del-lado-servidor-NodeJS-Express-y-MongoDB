# Módulo 3 - Registrar usuarios y autorizarlos

Proyecto desde cero para demostrar:

1. Usuario con `email`, `password`, `passwordResetToken`, `passwordResetTokenExpires` y `verificado`.
2. Modelo `Token` con referencia al usuario, token y fecha de creación.
3. Envío de email mediante Nodemailer.
4. Email de bienvenida con enlace de verificación.
5. Vistas de registro, login, recuperación y área privada.
6. `serializeUser` y `deserializeUser` en `config/passport.js`.
7. Credenciales correctas e incorrectas.
8. Protección de `/privado`: si no hay sesión, redirige a `/login`.
9. `POST /auth/login-jwt` devuelve un JWT con credenciales correctas.
10. `GET /api/bikes` exige un JWT válido; sin token devuelve error 401.

## Requisitos

- Node.js
- MongoDB local ejecutándose

## Instalación

```bash
npm install
```

Copia `.env.example` a `.env` y ajusta los valores.

Luego:

```bash
npm run dev
```

Abre:

http://localhost:3000

## Flujo de demostración

### 1. Registrar
POST `/auth/register`

Body JSON:
```json
{
  "email": "alumno@example.com",
  "password": "123456"
}
```

La respuesta incluye `verificationLinkDemo` para facilitar la demostración. Si SMTP está configurado, también se envía el correo real.

### 2. Verificar
Abre el `verificationLinkDemo`.

### 3. Login con Passport
POST `/auth/login` con `email` y `password`.

Credenciales incorrectas deben mostrar `?error=1`.

### 4. Protección de URL
Abre directamente `/privado` sin iniciar sesión. Debe redirigir a `/login`.

### 5. JWT en Postman
POST `/auth/login-jwt`

Body JSON:
```json
{
  "email": "alumno@example.com",
  "password": "123456"
}
```

Copia el `token`.

### 6. Bicicletas autorizadas
GET `/api/bikes`

Header:
`Authorization: Bearer TU_TOKEN`

Sin header/token:
`401 - Debes autenticarte con un token JWT`

Con token válido:
se devuelve la lista de bicicletas.

## Nota

El archivo `.env.example` no contiene credenciales reales. Para enviar correos reales configura una cuenta SMTP de prueba y sus credenciales en tu `.env`.
