const mongoose = require("mongoose");

const bikeSchema = new mongoose.Schema({
  marca: { type: String, required: true },
  modelo: { type: String, required: true },
  precio: { type: Number, required: true },
  disponible: { type: Boolean, default: true }
});

module.exports = mongoose.model("Bike", bikeSchema);