const Bike = require('../../models/bike');
const { connectMongo, clearMongo, closeMongo } = require('../helpers/mongo');

describe('Modelo Bicicleta', () => {
  beforeAll(async () => {
    await connectMongo();
  });

  beforeEach(async () => {
    await clearMongo();
  });

  afterAll(async () => {
    await clearMongo();
    await closeMongo();
  });

  it('debe crear una bicicleta y persistirla', async () => {
    const bike = await Bike.create({
      name: 'Bicicleta Centro',
      latitude: 14.0723,
      longitude: -87.1921,
      available: true
    });

    const saved = await Bike.findById(bike._id);

    expect(saved).not.toBeNull();
    expect(saved.name).toBe('Bicicleta Centro');
  });

  it('debe actualizar una bicicleta persistida', async () => {
    const bike = await Bike.create({
      name: 'Bicicleta Norte',
      latitude: 14.0742,
      longitude: -87.1904
    });

    bike.name = 'Bicicleta Actualizada';
    await bike.save();

    const saved = await Bike.findById(bike._id);

    expect(saved.name).toBe('Bicicleta Actualizada');
  });

  it('debe eliminar una bicicleta persistida', async () => {
    const bike = await Bike.create({
      name: 'Bicicleta Sur',
      latitude: 14.0705,
      longitude: -87.194
    });

    await Bike.findByIdAndDelete(bike._id);

    const saved = await Bike.findById(bike._id);

    expect(saved).toBeNull();
  });
});
