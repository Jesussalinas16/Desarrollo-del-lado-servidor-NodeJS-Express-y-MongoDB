const request = require('supertest');
const app = require('../app');
const Bike = require('../models/bike');
const { connectMongo, clearMongo, closeMongo } = require('./helpers/mongo');

describe('API de Bicicletas', () => {
  beforeAll(async () => {
    await connectMongo();
  });

  beforeEach(async () => {
    await clearMongo();
  });

  afterAll(async () => {
    await clearMongo();
    await closeMongo();
  });

  it('GET /api/bikes debe devolver las bicicletas', async () => {
    await Bike.create({
      name: 'Bicicleta Centro',
      latitude: 14.0723,
      longitude: -87.1921
    });

    const response = await request(app).get('/api/bikes');

    expect(response.status).toBe(200);
    expect(response.body.length).toBe(1);
    expect(response.body[0].name).toBe('Bicicleta Centro');
  });

  it('GET /api/bikes/:id debe devolver una bicicleta', async () => {
    const bike = await Bike.create({
      name: 'Bicicleta Centro',
      latitude: 14.0723,
      longitude: -87.1921
    });

    const response = await request(app).get(`/api/bikes/${bike._id}`);

    expect(response.status).toBe(200);
    expect(response.body.name).toBe('Bicicleta Centro');
  });

  it('POST /api/bikes debe crear una bicicleta', async () => {
    const response = await request(app)
      .post('/api/bikes')
      .send({
        name: 'Bicicleta Nueva',
        latitude: 14.073,
        longitude: -87.191,
        available: true
      });

    expect(response.status).toBe(201);
    expect(response.body.name).toBe('Bicicleta Nueva');

    const count = await Bike.countDocuments();
    expect(count).toBe(1);
  });

  it('PUT /api/bikes/:id debe actualizar una bicicleta', async () => {
    const bike = await Bike.create({
      name: 'Bicicleta Original',
      latitude: 14.0723,
      longitude: -87.1921
    });

    const response = await request(app)
      .put(`/api/bikes/${bike._id}`)
      .send({ name: 'Bicicleta Actualizada' });

    expect(response.status).toBe(200);
    expect(response.body.name).toBe('Bicicleta Actualizada');
  });

  it('DELETE /api/bikes/:id debe eliminar una bicicleta', async () => {
    const bike = await Bike.create({
      name: 'Bicicleta Para Eliminar',
      latitude: 14.0723,
      longitude: -87.1921
    });

    const response = await request(app)
      .delete(`/api/bikes/${bike._id}`);

    expect(response.status).toBe(200);

    const deleted = await Bike.findById(bike._id);
    expect(deleted).toBeNull();
  });
});
