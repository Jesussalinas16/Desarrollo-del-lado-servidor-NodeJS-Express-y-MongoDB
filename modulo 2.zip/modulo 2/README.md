# Módulo 2 - Red Bicicletas

Proyecto con Express, Mongoose, MongoDB y Jasmine.

## Instalación

npm install

## Base de datos

La aplicación utiliza la base local:

mongodb://127.0.0.1:27017/red_bicicletas

MongoDB debe estar ejecutándose antes de iniciar el servidor o ejecutar los tests.

## Ejecutar

npm start

## Desarrollo

npm run devstart

## Tests

npm test

## API

GET /api/bikes
GET /api/bikes/:id
POST /api/bikes
PUT /api/bikes/:id
DELETE /api/bikes/:id
