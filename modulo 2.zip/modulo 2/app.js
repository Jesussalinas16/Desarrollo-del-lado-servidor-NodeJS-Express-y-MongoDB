const express = require('express');
const bikeRoutes = require('./routes/bikes');

const app = express();

app.use(express.json());
app.use('/api/bikes', bikeRoutes);

app.get('/', (req, res) => {
  res.send('Bienvenido a Express');
});

app.use((req, res) => {
  res.status(404).json({ error: 'Recurso no encontrado' });
});

module.exports = app;
