const express = require('express');
const Bike = require('../models/bike');

const router = express.Router();

router.get('/', async (req, res) => {
  try {
    const bikes = await Bike.find();
    res.json(bikes);
  } catch (error) {
    res.status(500).json({ error: 'Error al obtener bicicletas' });
  }
});

router.get('/:id', async (req, res) => {
  try {
    const bike = await Bike.findById(req.params.id);

    if (!bike) {
      return res.status(404).json({ error: 'Bicicleta no encontrada' });
    }

    res.json(bike);
  } catch (error) {
    res.status(400).json({ error: 'ID inválido' });
  }
});

router.post('/', async (req, res) => {
  try {
    const bike = await Bike.create(req.body);
    res.status(201).json(bike);
  } catch (error) {
    res.status(400).json({ error: error.message });
  }
});

router.put('/:id', async (req, res) => {
  try {
    const bike = await Bike.findByIdAndUpdate(
      req.params.id,
      req.body,
      { new: true, runValidators: true }
    );

    if (!bike) {
      return res.status(404).json({ error: 'Bicicleta no encontrada' });
    }

    res.json(bike);
  } catch (error) {
    res.status(400).json({ error: 'Datos inválidos' });
  }
});

router.delete('/:id', async (req, res) => {
  try {
    const bike = await Bike.findByIdAndDelete(req.params.id);

    if (!bike) {
      return res.status(404).json({ error: 'Bicicleta no encontrada' });
    }

    res.json({ message: 'Bicicleta eliminada correctamente', bike });
  } catch (error) {
    res.status(400).json({ error: 'ID inválido' });
  }
});

module.exports = router;
