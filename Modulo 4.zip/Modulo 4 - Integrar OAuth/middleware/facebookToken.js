const axios = require("axios");

async function validateFacebookToken(req, res, next) {
  const token = req.headers.authorization?.replace("Bearer ", "");

  if (!token) {
    return res.status(401).json({ error: "Token de Facebook requerido" });
  }

  try {
    const appToken = `${process.env.FACEBOOK_APP_ID}|${process.env.FACEBOOK_APP_SECRET}`;
    const url = `https://graph.facebook.com/me?fields=id,name,email&access_token=${token}`;
    const response = await fetch(url);

    if (!response.ok) {
      return res.status(401).json({ error: "Token de Facebook inválido" });
    }

    const data = await response.json();
    const debugResponse = await fetch(`https://graph.facebook.com/debug_token?input_token=${token}&access_token=${appToken}`);

    if (!debugResponse.ok) {
      return res.status(401).json({ error: "No se pudo validar el token de Facebook" });
    }

    const debugData = await debugResponse.json();

    if (!debugData.data || !debugData.data.is_valid) {
      return res.status(401).json({ error: "Token de Facebook inválido" });
    }

    req.facebookUser = data;
    next();
  } catch (error) {
    res.status(401).json({ error: "Error validando token de Facebook" });
  }
}

module.exports = validateFacebookToken;