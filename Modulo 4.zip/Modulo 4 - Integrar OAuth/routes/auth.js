const express = require("express");
const crypto = require("crypto");
const User = require("../models/User");
const passport = require("passport");
const { sendEmail } = require("../services/email");
const validateFacebookToken = require("../middleware/facebookToken");

const router = express.Router();

router.get("/google", passport.authenticate("google", {
  scope: ["profile", "email"]
}));

router.get("/google/callback",
  passport.authenticate("google", { failureRedirect: "/login?error=google" }),
  (req, res) => res.redirect("/privado")
);

router.get("/facebook", passport.authenticate("facebook", {
  scope: ["email"]
}));

router.get("/facebook/callback",
  passport.authenticate("facebook", { failureRedirect: "/login?error=facebook" }),
  (req, res) => res.redirect("/privado")
);

router.get("/facebook/validate", validateFacebookToken, (req, res) => {
  res.json({
    message: "Token de Facebook válido",
    usuario: req.facebookUser
  });
});

router.get("/logout", (req, res) => {
  req.logout(() => res.redirect("/"));
});

router.post("/send-verification", async (req, res) => {
  try {
    const email = String(req.body.email || "").trim().toLowerCase();
    const user = await User.findOne({ email });

    if (!user) {
      return res.status(404).json({ error: "Usuario no encontrado" });
    }

    const token = crypto.randomBytes(32).toString("hex");
    user.verificado = false;
    await user.save();

    const link = `${process.env.BASE_URL || "http://localhost:3000"}/auth/verify/${token}`;

    const mailResult = await sendEmail(
      email,
      "Verificación de cuenta",
      `<h2>Bienvenido</h2><p>Verifica tu cuenta:</p><a href="${link}">${link}</a>`
    );

    res.json({
      message: "Email enviado",
      provider: process.env.NODE_ENV === "production" ? "SendGrid" : "Ethereal",
      preview: mailResult
    });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

router.get("/verify/:token", async (req, res) => {
  res.send("<h2>Cuenta verificada</h2><a href='/login'>Login</a>");
});

module.exports = router;