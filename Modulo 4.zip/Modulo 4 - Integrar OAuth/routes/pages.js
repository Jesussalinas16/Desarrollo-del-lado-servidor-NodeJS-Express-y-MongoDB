const express = require("express");
const path = require("path");

const router = express.Router();

router.get("/", (req, res) => {
  res.sendFile(path.join(__dirname, "../public/index.html"));
});

router.get("/login", (req, res) => {
  res.sendFile(path.join(__dirname, "../public/login.html"));
});

router.get("/privado", (req, res) => {
  if (!req.isAuthenticated()) {
    return res.redirect("/login");
  }

  res.sendFile(path.join(__dirname, "../public/privado.html"));
});

module.exports = router;