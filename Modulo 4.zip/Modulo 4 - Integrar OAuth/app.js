require("dotenv").config();
require("newrelic");

const express = require("express");
const session = require("express-session");
const passport = require("passport");
const mongoose = require("mongoose");

require("./config/passport");

const authRoutes = require("./routes/auth");
const pageRoutes = require("./routes/pages");

const app = express();

app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(express.static("public"));

app.use(session({
  secret: process.env.SESSION_SECRET || "session-secret",
  resave: false,
  saveUninitialized: false
}));

app.use(passport.initialize());
app.use(passport.session());

app.use("/", pageRoutes);
app.use("/auth", authRoutes);

app.use((req, res) => {
  res.status(404).json({ error: "Recurso no encontrado" });
});

const port = process.env.PORT || 3000;
const mongoUri = process.env.MONGO_URI || "mongodb://127.0.0.1:27017/modulo4";

mongoose.connect(mongoUri)
  .then(() => {
    app.listen(port, () => {
      console.log(`http://localhost:${port}`);
      console.log(`NODE_ENV=${process.env.NODE_ENV || "development"}`);
      console.log(`MongoDB conectado`);
    });
  })
  .catch((error) => {
    console.error(error.message);
    process.exit(1);
  });