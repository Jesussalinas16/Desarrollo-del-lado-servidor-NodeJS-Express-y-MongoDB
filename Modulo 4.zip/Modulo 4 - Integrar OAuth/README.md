Modulo 4

NODE_ENV=development usa Mongo local y Ethereal.

NODE_ENV=production usa MONGO_URI de Mongo Atlas y SendGrid.

Para instalar:
npm install

Para ejecutar:
npm run dev

Para Google configura:
GOOGLE_CLIENT_ID
GOOGLE_CLIENT_SECRET
GOOGLE_CALLBACK_URL

Para Facebook configura:
FACEBOOK_APP_ID
FACEBOOK_APP_SECRET

Para Ethereal configura:
ETHEREAL_USER
ETHEREAL_PASS

Para producción configura:
MONGO_URI
SENDGRID_API_KEY
SENDGRID_FROM
NEW_RELIC_LICENSE_KEY

Rutas:
GET /auth/google
GET /auth/facebook
GET /auth/facebook/validate
GET /privado
GET /login

El modelo User contiene findOneOrCreateByGoogle.

app.js carga newrelic antes de Express.

Heroku:
heroku create
git push heroku main
heroku config:set NODE_ENV=production
heroku config:set MONGO_URI="mongodb+srv://..."
heroku config:set SENDGRID_API_KEY="..."
heroku config:set SENDGRID_FROM="..."
heroku config:set NEW_RELIC_LICENSE_KEY="..."
heroku logs --tail

En Heroku las variables se configuran como Config Vars.
