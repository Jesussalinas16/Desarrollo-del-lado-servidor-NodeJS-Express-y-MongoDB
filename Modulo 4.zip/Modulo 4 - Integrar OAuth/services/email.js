const nodemailer = require("nodemailer");
const sgMail = require("@sendgrid/mail");

async function sendEmail(to, subject, html) {
  if (process.env.NODE_ENV === "production") {
    sgMail.setApiKey(process.env.SENDGRID_API_KEY);

    await sgMail.send({
      to,
      from: process.env.SENDGRID_FROM,
      subject,
      html
    });

    return "sendgrid";
  }

  const transporter = nodemailer.createTransport({
    host: "smtp.ethereal.email",
    port: 587,
    secure: false,
    auth: {
      user: process.env.ETHEREAL_USER,
      pass: process.env.ETHEREAL_PASS
    }
  });

  const info = await transporter.sendMail({
    from: process.env.ETHEREAL_USER,
    to,
    subject,
    html
  });

  return nodemailer.getTestMessageUrl(info);
}

module.exports = { sendEmail };