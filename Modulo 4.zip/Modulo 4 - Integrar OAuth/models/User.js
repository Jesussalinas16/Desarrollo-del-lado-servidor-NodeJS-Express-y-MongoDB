const mongoose = require("mongoose");

const userSchema = new mongoose.Schema({
  email: {
    type: String,
    required: true,
    unique: true,
    lowercase: true,
    trim: true
  },
  password: {
    type: String,
    default: null
  },
  nombre: {
    type: String,
    default: ""
  },
  googleId: {
    type: String,
    default: null
  },
  facebookId: {
    type: String,
    default: null
  },
  verificado: {
    type: Boolean,
    default: false
  }
}, { timestamps: true });

userSchema.statics.findOneOrCreateByGoogle = async function(profile) {
  let user = await this.findOne({
    $or: [
      { googleId: profile.id },
      { email: profile.emails && profile.emails[0] ? profile.emails[0].value.toLowerCase() : "" }
    ]
  });

  if (user) {
    if (!user.googleId) {
      user.googleId = profile.id;
      await user.save();
    }
    return user;
  }

  return this.create({
    email: profile.emails && profile.emails[0] ? profile.emails[0].value.toLowerCase() : `${profile.id}@google.local`,
    nombre: profile.displayName || "",
    googleId: profile.id,
    verificado: true
  });
};

userSchema.statics.findOneOrCreateByFacebook = async function(profile) {
  let user = await this.findOne({
    $or: [
      { facebookId: profile.id },
      { email: profile.emails && profile.emails[0] ? profile.emails[0].value.toLowerCase() : "" }
    ]
  });

  if (user) {
    if (!user.facebookId) {
      user.facebookId = profile.id;
      await user.save();
    }
    return user;
  }

  return this.create({
    email: profile.emails && profile.emails[0] ? profile.emails[0].value.toLowerCase() : `${profile.id}@facebook.local`,
    nombre: profile.displayName || "",
    facebookId: profile.id,
    verificado: true
  });
};

module.exports = mongoose.model("User", userSchema);