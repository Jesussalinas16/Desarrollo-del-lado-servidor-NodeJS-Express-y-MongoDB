# Módulo 1 - Proyecto Express

Proyecto realizado con Node.js y Express que incluye:

- Servidor Express.
- Página de bienvenida.
- Mapa centrado en Tegucigalpa.
- Marcadores de ubicaciones.
- Colección de bicicletas en memoria.
- Modelo de bicicleta con Mongoose.
- API REST para bicicletas.
- Script `devstart` con Nodemon.
- Configuración preparada para trabajar con Bitbucket.

## Requisitos

- Node.js 18 o superior.
- npm.
- MongoDB local (opcional para los endpoints que usan Mongoose).

## Instalación

```bash
npm install
```

## Ejecutar en modo normal

```bash
npm start
```

Abrir:

`http://localhost:3000`

## Ejecutar en desarrollo

```bash
npm run devstart
```

## API

- `GET /api/bikes` - Lista las bicicletas en memoria.
- `GET /api/bikes/:id` - Obtiene una bicicleta por ID.
- `POST /api/bikes` - Agrega una bicicleta a la colección en memoria.
- `PUT /api/bikes/:id` - Actualiza una bicicleta.
- `DELETE /api/bikes/:id` - Elimina una bicicleta.

## Mongoose

El modelo se encuentra en:

`models/bike.js`

La conexión a MongoDB utiliza:

`mongodb://127.0.0.1:27017/modulo1_bikes`

## Bitbucket

Después de crear el repositorio en Bitbucket:

```bash
git init
git add .
git commit -m "Proyecto Modulo 1"
git branch -M main
git remote add origin URL_DE_TU_REPOSITORIO
git push -u origin main
```

El archivo README está incluido en el proyecto para subirlo al repositorio.
