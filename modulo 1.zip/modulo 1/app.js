const express = require('express');
const path = require('path');
const mongoose = require('mongoose');
const bikeRoutes = require('./routes/bikes');

const app = express();
const PORT = process.env.PORT || 3000;

app.use(express.json());
app.use(express.urlencoded({ extended: true }));

app.use(express.static(path.join(__dirname, 'public')));

app.get('/api', (req, res) => {
  res.json({
    message: 'API de bicicletas funcionando correctamente',
    endpoints: [
      'GET /api/bikes',
      'GET /api/bikes/:id',
      'POST /api/bikes',
      'PUT /api/bikes/:id',
      'DELETE /api/bikes/:id'
    ]
  });
});

app.use('/api/bikes', bikeRoutes);

app.use((req, res) => {
  res.status(404).json({ error: 'Recurso no encontrado' });
});

async function startServer() {
  try {
    // MongoDB es opcional para este módulo. La API principal usa memoria.
    const mongoUrl = process.env.MONGO_URI || 'mongodb://127.0.0.1:27017/modulo1_bikes';

    try {
      await mongoose.connect(mongoUrl, { serverSelectionTimeoutMS: 1500 });
      console.log('MongoDB conectado.');
    } catch (error) {
      console.log('MongoDB no disponible. El proyecto continuará usando la colección en memoria.');
    }

    app.listen(PORT, () => {
      console.log(`Servidor Express ejecutándose en http://localhost:${PORT}`);
    });
  } catch (error) {
    console.error('No se pudo iniciar el servidor:', error);
    process.exit(1);
  }
}

startServer();
