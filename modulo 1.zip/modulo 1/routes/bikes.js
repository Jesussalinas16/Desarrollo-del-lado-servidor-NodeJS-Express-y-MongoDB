const express = require('express');

const router = express.Router();

// Colección de bicicletas en memoria.
// Las dos ubicaciones están cerca del centro de Tegucigalpa.
let bikes = [
  {
    id: 1,
    name: 'Bicicleta Centro 1',
    latitude: 14.0723,
    longitude: -87.1921,
    available: true
  },
  {
    id: 2,
    name: 'Bicicleta Centro 2',
    latitude: 14.0742,
    longitude: -87.1904,
    available: true
  }
];

router.get('/', (req, res) => {
  res.json(bikes);
});

router.get('/:id', (req, res) => {
  const id = Number(req.params.id);
  const bike = bikes.find(item => item.id === id);

  if (!bike) {
    return res.status(404).json({ error: 'Bicicleta no encontrada' });
  }

  res.json(bike);
});

router.post('/', (req, res) => {
  const { name, latitude, longitude, available = true } = req.body;

  if (!name || latitude === undefined || longitude === undefined) {
    return res.status(400).json({
      error: 'name, latitude y longitude son obligatorios'
    });
  }

  const bike = {
    id: bikes.length ? Math.max(...bikes.map(item => item.id)) + 1 : 1,
    name,
    latitude: Number(latitude),
    longitude: Number(longitude),
    available: Boolean(available)
  };

  bikes.push(bike);
  res.status(201).json(bike);
});

router.put('/:id', (req, res) => {
  const id = Number(req.params.id);
  const index = bikes.findIndex(item => item.id === id);

  if (index === -1) {
    return res.status(404).json({ error: 'Bicicleta no encontrada' });
  }

  bikes[index] = {
    ...bikes[index],
    ...req.body,
    id
  };

  res.json(bikes[index]);
});

router.delete('/:id', (req, res) => {
  const id = Number(req.params.id);
  const index = bikes.findIndex(item => item.id === id);

  if (index === -1) {
    return res.status(404).json({ error: 'Bicicleta no encontrada' });
  }

  const deleted = bikes.splice(index, 1)[0];
  res.json({
    message: 'Bicicleta eliminada correctamente',
    bike: deleted
  });
});

module.exports = router;
